# COPY MARKET

COPY MARKET is a rebranded, self-hosted Polymarket copy-trading application derived from the user-provided PolyCopy source package.

## What is included

- Multi-trader copy trading for Polymarket
- Local dashboard, REST API, and Swagger docs
- Local NeDB storage
- MCP server support
- Trader discovery, simulation, and health-check scripts
- Markdown documentation and a reusable build prompt

## Tested status

The packaged COPY MARKET build was validated locally with:

```bash
npm ci
npm test -- --runInBand
npm run build
```

At packaging time, all 3 Jest suites passed with 40/40 tests.

## Local quick start

```bash
cp .env.example .env
# edit .env with your wallet, RPC, and Polymarket settings
npm ci
npm run build
npm start
```

Open:

- Web UI: `http://localhost:3000`
- Swagger: `http://localhost:3000/docs`
- Health: `http://localhost:3000/api/health`

## Notes

This package is code-tested locally, but live trading still requires valid Polymarket credentials, Polygon RPC access, wallet funding, and your own risk controls.

See:

- `docs/QUICK_START.md`
- `docs/TEST_REPORT.md`
- `docs/COPY_MARKET_PROMPT.md`
- `docs/DERIVATION_NOTE.md`
